#!/bin/bash

TARS_PATH/tarsconfig/util/execute.sh tarsconfig start
