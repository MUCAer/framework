#!/bin/bash

sh TARS_PATH/tarsstat/util/execute.sh tarsstat start

