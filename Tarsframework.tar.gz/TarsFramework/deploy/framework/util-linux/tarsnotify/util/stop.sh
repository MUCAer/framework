#!/bin/bash

sh TARS_PATH/tarsnotify/util/execute.sh tarsnotify stop


