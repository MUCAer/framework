# Build docker

in TarsFramework source directory:
```
deploy/docker.sh v1 arm64
deploy/docker.sh v1 amd64
```


