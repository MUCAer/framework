该工程是Tars框架C++语言IDL的源代码

代码目录介绍


目录名称 |功能
------------------|----------------
tarsgrammer   | 定义tars词法和语法的分析规则
tarsparse     | 解析tars词语和语法分析的源码实现
tars2cpp      | 通过tars文件生成 C++ 代码的IDL工具的源码实现
tars2c        | 通过tars文件生成 C 代码的IDL工具的源码实现
tars2cs       | 通过tars文件生成 C# 代码的IDL工具的源码实现
tars2oc       | 通过tars文件生成 ObjectC 代码的IDL工具的源码实现
tars2php      | 通过tars文件生成 PHP 代码的IDL工具的源码实现
tars2python   | 通过tars文件生成 Python 代码的IDL工具的源码实现
tars2node     | 通过tars文件生成 Node.js 代码的IDL工具的源码实现
tars2android  | 通过tars文件生成 Android 代码的IDL工具的源码实现
tars2case     | 通过tars文件生成 tars 服务生成测试用例
pb2tarscpp    | 通过proto文件生成tars C++ 代码的protoc插件源码实现
