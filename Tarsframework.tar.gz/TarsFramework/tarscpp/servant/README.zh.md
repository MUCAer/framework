该工程是Tars框架C++语言的rpc实现的源代码

目录名称 |功能
------------------|----------------
wup                   |rpc框架的统一的通信协议(tars/wup协议)和协议的编解码实现方式
protocol              |rpc框架定义的底层通信的返回码和与框架基础服务进行交互的通信接口文件
servant/libservant    |rpc框架的源码实现
jmem                  |基于tars协议的内存数据结构组件的源码实现
promise               |基于promise异步编程的源码实现
makefile              |使用TARS框架C++语言的编译源代码的makefile实现
script                |生成TARS服务模版代码的脚本工具
